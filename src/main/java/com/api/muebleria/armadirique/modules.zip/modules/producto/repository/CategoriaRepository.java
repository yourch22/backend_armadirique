package com.api.muebleria.armadirique.modules.producto.repository;
import com.api.muebleria.armadirique.modules.producto.entity.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
}